#ifndef SERVEUR_H
#define SERVEUR_H

#include <QTcpSocket>
#include <QTcpServer>
#include <QAbstractSocket>

class Serveur: public QTcpServer
{
    Q_OBJECT
public:
    explicit Serveur(QObject *parent = 0);
    void startServer(int port);

protected:
    void incomingConnection(int handle);

};

#endif // SERVEUR_H
