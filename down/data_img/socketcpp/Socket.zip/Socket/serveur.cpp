#include "serveur.h"
#include "client.h"
#include <QDebug>

Serveur::Serveur(QObject *parent) : QTcpServer(parent)
{
    // Constructeur vide, parce que dans ce cas, c'est pas important !
}

// Procédure de lancement du serveur
void Serveur::startServer(int port)
{
    // Ici, condition: si le serveur est lancé ou pas
    if(listen(QHostAddress("127.0.0.1"), port))
    {
        qDebug()<<"Le serveur est bien démarré !";
        // Le serveur est enfin démarré
    }
    else
    {
        // Le serveur n'a pas pu... port déjà pris ?
    }
}

// Evénement appelé lors d'une connexion
void Serveur::incomingConnection(int handle)
{
	// On crée un nouveau client
    Client* nouveauClient = new Client(this);
	// On lui attribue la valeur de la connexion socket
    nouveauClient->setSocket(handle);
}
