#ifndef CLIENT_H
#define CLIENT_H

#include <QTcpSocket>
#include <QAbstractSocket>
#include <QObject>

class Client: public QObject
{
    Q_OBJECT
public:
    explicit Client(QObject *parent = 0);
    void setSocket(int socketDescriptor);

public slots:
    void disconnected();
    void readyRead();

private:
    QTcpSocket *socket;
};

#endif // CLIENT_H
