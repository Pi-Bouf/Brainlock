#include "client.h"
#include <QDebug>

Client::Client(QObject *parent) :
    QObject(parent)
{
	// Toujours un constructeur vide
}

// Procédure attribuant la valeur du socket
void Client::setSocket(int socketDescriptor)
{
	// On crée un nouveau socket
    socket = new QTcpSocket(this);

	// On connecte les événements à des procédures présentes dans cette classe
    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));
    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()));

	// On attribue la valeur du socket au socket créé
    socket->setSocketDescriptor(socketDescriptor);

    qDebug()<<"Je suis un nouveau client ! <3";
}

// Procédure d'appel lors de la déconnexion du client
void Client::disconnected()
{
    qDebug()<<"Déconnexion !";
}

// Procédure d'appel lors d'un message arrivant
void Client::readyRead()
{
	// On affiche le message reçus
    QString text = socket->readAll();
    qDebug()<<"Message: " + text;
}
