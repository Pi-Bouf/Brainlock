#include <QCoreApplication>
#include <serveur.h>
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Instanciation du serveur
    Serveur server;
	// Appel de la procédure pour lancer le serveur sur le port 9999
    server.startServer(9999);

    return a.exec();
}
