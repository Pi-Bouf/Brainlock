-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 10, 2017 at 09:04 AM
-- Server version: 5.1.57
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `a3264731_bl`
--

-- --------------------------------------------------------

--
-- Table structure for table `brain_article`
--

CREATE TABLE `brain_article` (
  `artID` smallint(6) NOT NULL AUTO_INCREMENT,
  `artTitleShort` varchar(60) DEFAULT NULL,
  `artTitleLong` varchar(150) DEFAULT NULL,
  `artText` mediumtext,
  `artDate` date DEFAULT NULL,
  `artBin` tinyint(4) NOT NULL,
  `artAuteur` smallint(6) NOT NULL,
  `menuID` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`artID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `brain_article`
--

INSERT INTO `brain_article` VALUES(1, 'Accueil', 'Bienvenue sur BrainLock !', 'Bienvenue sur cette boîte à outils, destiner à répertorier un tas de fonctions et codes utiles pour la programmation.<br />\r\n<br />\r\nEnvie d''un code qui marche ? Dirigez-vous vers un menu et fouillez... ;)<br />\r\n<br />\r\nLes codes sont testé avant leur publication, avec des explications et commentaires !<br />\r\n<br />\r\n<i>Bonne navigation !</i>', '2016-04-25', 0, 1, 1);
INSERT INTO `brain_article` VALUES(2, 'Socket Asynchrone', 'Les Sockets Asynchrones pour un plus beau serveur !', '<p><strong><em>Qu\\''est-ce que des sockets synchrone ?</em></strong></p><br />\r\n<p>Pour expliquer correctement, je vais commencer par un contre exemple: les sockets synchrone (bloquante). <br />Ces derni&egrave;res, en th&eacute;orie, sont bloquante: un client se connecte, le serveur fait une action en fonction de ce qu\\''il re&ccedil;oit et reprend du d&eacute;but, comme une boucle. <br />Il n\\''y a aucun &eacute;v&eacute;nement lors de la r&eacute;ception d\\''un message: le serveur attend gentiment qu\\''un message arrive, fais une action et se remet &agrave; &eacute;couter, sans faire autre chose.</p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>while(true)<br />\r\n{<br />\r\n    Serveur read(); // Il attend qu\\''un message arrive et ne fait rien d\\''autre<br />\r\n    Serveur enTrainDeLire; // Il lit un message qui arrive<br />\r\n    if(message == \\"...\\")<br />\r\n    {<br />\r\n        jeFaisUneAction(); // On fait une action<br />\r\n    }<br />\r\n    // On se remet &agrave; attendre...<br />\r\n}</code></pre><br />\r\n<p><em>O&ugrave; est le probl&egrave;me dans ce cas l&agrave; ?</em> <br />1) Et s\\''il y avait autre chose &agrave; faire ? <br />2) Et si on a plusieurs client ? (Chat, serveur de jeu,...)</p><br />\r\n<p>En gros, en dernier exemple, imaginons un chat: le client envoie un message, le serveur lui r&eacute;pond, puis le client, puis le serveur,... Alors qu\\''en asynchrone, on envoie plusieurs message, le serveur r&eacute;pond (ou pas), puis on en envoie encore 3, il nous en r&eacute;pond 2,...</p><br />\r\n<p><strong><em>Donc, qu\\''est-ce que des sockets asynchrone ?</em></strong></p><br />\r\n<p>Il s\\''agit de l\\''oppos&eacute; ! Il peut recevoir de multiple messages et connexions et il peut les traiter s&eacute;par&eacute;ment. <br />Dans cas l&agrave;, il s\\''agit d\\''un serveur recevant un &eacute;v&eacute;nement d\\''une nouvelle connexion, qui va nous permettre de cr&eacute;er une instance de classe Client, qui donc sera destin&eacute; uniquement &agrave; cette connexion. <br />Des &eacute;v&eacute;nements seront connect&eacute;, comme par exemple le Client#2 enverra un message au serveur, seulement son instance pourra le traiter, alors que le Client#1 et Client#3 ne le pourront pas. <br />Tout sera cloisonn&eacute; et fait par &eacute;v&eacute;nement: donc socket <strong>asynchrone</strong> !</p><br />\r\n<p><u>Petit sch&eacute;ma:</u></p><br />\r\n<center><img src=\\"down/data_img/socketcpp/Graph.png\\" /></center><br />\r\n<p><strong>Ici, le main.cpp</strong></p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>#include <br />\r\n#include <br />\r\n<br />\r\nusing namespace std;<br />\r\n<br />\r\nint main(int argc, char *argv[])<br />\r\n{<br />\r\n    QCoreApplication a(argc, argv);<br />\r\n<br />\r\n	// Instanciation du serveur<br />\r\n    Serveur server;<br />\r\n	// Appel de la proc&eacute;dure pour lancer le serveur sur le port 9999<br />\r\n    server.startServer(9999);<br />\r\n<br />\r\n    return a.exec();<br />\r\n}<br />\r\n</code></pre><br />\r\n<p><strong>Ici, le serveur.cpp</strong></p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>#include \\"serveur.h\\"<br />\r\n#include \\"client.h\\"<br />\r\n<br />\r\nServeur::Serveur(QObject *parent) : QTcpServer(parent)<br />\r\n{<br />\r\n    // Constructeur vide, parce que dans ce cas, c\\''est pas important !<br />\r\n}<br />\r\n<br />\r\n// Proc&eacute;dure de lancement du serveur<br />\r\nvoid Serveur::startServer(int port)<br />\r\n{<br />\r\n    // Ici, condition: si le serveur est lanc&eacute; ou pas<br />\r\n    if(listen(QHostAddress(\\"127.0.0.1\\"), port))<br />\r\n    {<br />\r\n        // Le serveur est enfin d&eacute;marr&eacute;<br />\r\n    }<br />\r\n    else<br />\r\n    {<br />\r\n        // Le serveur n\\''a pas pu... port d&eacute;j&agrave; pris ?<br />\r\n    }<br />\r\n}<br />\r\n<br />\r\n// Ev&eacute;nement appel&eacute; lors d\\''une connexion<br />\r\nvoid Serveur::incomingConnection(int handle)<br />\r\n{<br />\r\n	// On cr&eacute;e un nouveau client<br />\r\n    Client* nouveauClient = new Client(this);<br />\r\n	// On lui attribue la valeur de la connexion socket<br />\r\n    nouveauClient-&gt;setSocket(handle);<br />\r\n}<br />\r\n</code></pre><br />\r\n<p><strong>Et pour finir, le client.cpp</strong></p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>#include \\"client.h\\"<br />\r\n#include <br />\r\n#include <br />\r\n<br />\r\nusing namespace std;<br />\r\n<br />\r\nClient::Client(QObject *parent) :<br />\r\n    QObject(parent)<br />\r\n{<br />\r\n	// Toujours un constructeur vide<br />\r\n}<br />\r\n<br />\r\n// Proc&eacute;dure attribuant la valeur du socket<br />\r\nvoid Client::setSocket(int socketDescriptor)<br />\r\n{<br />\r\n	// On cr&eacute;e un nouveau socket<br />\r\n    socket = new QTcpSocket(this);<br />\r\n<br />\r\n	// On connecte les &eacute;v&eacute;nements &agrave; des proc&eacute;dures pr&eacute;sentes dans cette classe<br />\r\n    connect(socket, SIGNAL(disconnected()), this, SLOT(disconnected()));<br />\r\n    connect(socket, SIGNAL(readyRead()), this, SLOT(readyRead()));<br />\r\n<br />\r\n	// On attribue la valeur du socket au socket cr&eacute;&eacute;<br />\r\n    socket-&gt;setSocketDescriptor(socketDescriptor);<br />\r\n}<br />\r\n<br />\r\n// Proc&eacute;dure d\\''appel lors de la d&eacute;connexion du client<br />\r\nvoid Client::disconnected()<br />\r\n{<br />\r\n    qDebug()&lt;&lt;\\"D&eacute;connexion !\\";<br />\r\n}<br />\r\n<br />\r\n// Proc&eacute;dure d\\''appel lors d\\''un message arrivant<br />\r\nvoid Client::readyRead()<br />\r\n{<br />\r\n	// On affiche le message re&ccedil;us<br />\r\n    QString text = socket-&gt;readAll();<br />\r\n    qDebug()&lt;&lt;\\"Message: \\" + text;<br />\r\n}<br />\r\n</code></pre><br />\r\n<p><em><strong>Code source: </strong></em> <a href=\\"../down/data_img/socketcpp/Socket.zip\\">cliquez ici</a> !</p>', '2016-04-26', 0, 1, 3);
INSERT INTO `brain_article` VALUES(3, '[Console] Couleur de texte', 'Mettre de la couleur dans vos consoles !', '<p><em><strong>Voici une librairie permettant d\\''afficher un texte color&eacute; dans la console !</strong></em></p><br />\r\n<p>La biblioth&egrave;que nous permet d\\''utiliser le <u>cout</u>, mais celui-ci ne s\\''affiche qu\\''en blanc sur noir, ou selon le style de la console. Et c\\''est moche. En ajoutant certain code dans le <em>cout</em>, on permet de le mettre en couleur, en gras ou bien italique (voir les 3 !)</p><br />\r\n<p><strong><em>Exemple:</em></strong></p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>void Console::BlueText(string text, int option)<br />\r\n{<br />\r\n    // \\"\\\\x1B[34m\\" ==&gt; ici, c\\''est la couleur bleu<br />\r\n    // \\"\\\\x1B[0m\\" ==&gt; ici, c\\''est la remise &agrave; l\\''&eacute;tat initial (afin de pas garder ce style jusqu\\''&agrave; la fin du programme...<br />\r\n    cout&lt;&lt;\\"\\\\x1B[34m\\"&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}</code></pre><br />\r\n<p>Gr&acirc;ce &agrave; d\\''autres codes, on peut donc changer le style de code et gr&acirc;ce &agrave; ces deux fichiers tout fait, on peut le faire encore plus facilement: console.cpp:</p><br />\r\n<pre class=\\"language-cpp line-numbers\\"><code>#include \\"console.h\\"<br />\r\n<br />\r\nvoid Console::BlueText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[34m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::RedText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[31m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::GreenText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[32m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::YellowText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[33m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::MagentaText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[35m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::CyanText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[36m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\nvoid Console::WhiteText(string text, int option)<br />\r\n{<br />\r\n    cout&lt;&lt;\\"\\\\x1B[37m\\"&lt;&lt;StyleText(option)&lt;&lt;text&lt;&lt;\\"\\\\x1B[0m\\"&lt;&lt;endl;<br />\r\n}<br />\r\n<br />\r\n<br />\r\nstring Console::StyleText(int option)<br />\r\n{<br />\r\n    string textOption;<br />\r\n<br />\r\n    switch(option)<br />\r\n    {<br />\r\n	// Italique<br />\r\n    case 2:<br />\r\n        textOption = \\"\\\\x1B[1m\\";<br />\r\n        break;<br />\r\n	// Gras<br />\r\n    case 3:<br />\r\n        textOption = \\"\\\\x1B[3m\\";<br />\r\n        break;<br />\r\n    }<br />\r\n<br />\r\n    return textOption;<br />\r\n}<br />\r\n</code></pre><br />\r\n<p>console.h</p><br />\r\n<pre class=\\"line-numbers language-cpp\\"><code>#ifndef CONSOLE_H<br />\r\n#define CONSOLE_H<br />\r\n<br />\r\n#include <br />\r\n#include <br />\r\n#include <br />\r\n<br />\r\nusing namespace std;<br />\r\n<br />\r\nclass Console<br />\r\n{<br />\r\n<br />\r\npublic:<br />\r\n    static void BlueText(string text, int option);<br />\r\n    static void RedText(string text, int option);<br />\r\n    static void GreenText(string text, int option);<br />\r\n    static void YellowText(string text, int option);<br />\r\n    static void MagentaText(string text, int option);<br />\r\n    static void CyanText(string text, int option);<br />\r\n    static void WhiteText(string text, int option);<br />\r\n    static string StyleText(int option);<br />\r\n};<br />\r\n<br />\r\n#endif // CONSOLE_H<br />\r\n</code></pre><br />\r\n<p>Amusez-vous bien ! :D</p>', '2016-04-27', 0, 1, 3);
INSERT INTO `brain_article` VALUES(4, 'Mode Immersif', 'Profiter de TOUT son écran grâce au mode immersif !', '<p><span style=\\"font-family: impact, sans-serif;\\">Le mode immersif permet de retirer la barre noir du haut, mais &eacute;galement la barre de navigation du bas.</span></p><br />\r\n<p><span style=\\"font-family: impact, sans-serif;\\">Mais dans ce code, on peut &eacute;galement remettre le mode immersif APRES ouverture du clavier.</span></p><br />\r\n<p style=\\"text-align: center;\\"><span style=\\"font-family: impact, sans-serif;\\"><img src=\\"../down/data_img/modeimmersif/Screen.png\\" alt=\\"Screen\\" width=\\"315\\" height=\\"560\\" /></span></p><br />\r\n<pre class=\\"line-numbers language-java\\"><code>public class MainActivity extends Activity {<br />\r\n<br />\r\n<br />\r\n    @Override<br />\r\n    protected void onCreate(Bundle savedInstanceState) {<br />\r\n        super.onCreate(savedInstanceState);<br />\r\n        // Mise en place du contenu<br />\r\n        setContentView(R.layout.layout_login);<br />\r\n        // R&eacute;cup&eacute;ration des donn&eacute;es de la vue<br />\r\n        final View decorView = getWindow().getDecorView();<br />\r\n        // Cr&eacute;ation de l\\''&eacute;v&eacute;nement, appelant le mode immersif<br />\r\n        // Il permet aussi de retourner en immersif apr&egrave;s ouverture clavier<br />\r\n        decorView.setOnSystemUiVisibilityChangeListener(<br />\r\n                new View.OnSystemUiVisibilityChangeListener() {<br />\r\n                    @Override<br />\r\n                    public void onSystemUiVisibilityChange(int i) {<br />\r\n                        setImmersiveMode();<br />\r\n                    }<br />\r\n                });<br />\r\n    }<br />\r\n<br />\r\n<br />\r\n    // Proc&eacute;dure mettant en place le mode immersif<br />\r\n    private void setImmersiveMode()<br />\r\n    {<br />\r\n        // Ajout du mode immersif<br />\r\n        getWindow().getDecorView().setSystemUiVisibility(<br />\r\n                View.SYSTEM_UI_FLAG_LAYOUT_STABLE<br />\r\n                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION<br />\r\n                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN<br />\r\n                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION<br />\r\n                        | View.SYSTEM_UI_FLAG_FULLSCREEN<br />\r\n                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);<br />\r\n    }<br />\r\n<br />\r\n<br />\r\n    @Override<br />\r\n    public void onWindowFocusChanged(boolean hasFocus) {<br />\r\n        super.onWindowFocusChanged(hasFocus);<br />\r\n        // Lorsque l\\''on retrouve le focus, on retourne en mode immersif<br />\r\n        setImmersiveMode();<br />\r\n    }<br />\r\n<br />\r\n    @Override<br />\r\n    protected void onResume() {<br />\r\n        super.onResume();<br />\r\n        // Lorsque l\\''on retrouve le focus, on retourne en mode immersif<br />\r\n        setImmersiveMode();<br />\r\n    }<br />\r\n<br />\r\n}</code></pre>', '2016-05-03', 0, 1, 2);
INSERT INTO `brain_article` VALUES(5, 'Procédure', 'Les procédures stockés', '<p>qsd</p>', '2016-06-12', 0, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `brain_menu`
--

CREATE TABLE `brain_menu` (
  `menuID` tinyint(4) NOT NULL AUTO_INCREMENT,
  `menuName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`menuID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `brain_menu`
--

INSERT INTO `brain_menu` VALUES(1, 'Accueil');
INSERT INTO `brain_menu` VALUES(2, 'JAVA (Android)');
INSERT INTO `brain_menu` VALUES(3, 'C++ (Qt)');
INSERT INTO `brain_menu` VALUES(4, 'SQL');

-- --------------------------------------------------------

--
-- Table structure for table `brain_user`
--

CREATE TABLE `brain_user` (
  `userID` smallint(6) NOT NULL AUTO_INCREMENT,
  `userPrenom` varchar(20) DEFAULT NULL,
  `userLogin` varchar(20) DEFAULT NULL,
  `userPassword` varchar(32) DEFAULT NULL,
  `userLevel` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `brain_user`
--

INSERT INTO `brain_user` VALUES(1, 'Pierre', 'pbouffier', '96e79218965eb72c92a549dd5a330112', '5');
